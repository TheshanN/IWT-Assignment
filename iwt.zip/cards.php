<!DOCTYPE html>
<html>
<head>





<title>User Account</title>
<link rel="stylesheet" type="text/css" href="./cards.css">

<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="footer.css">
    <title>footer</title>
	
	
	
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="header.css">
    <title>header</title>
	
	
	
	

</head>
<body>


    <!--header-->

        <?php include "header.php" ?>
		
		

</head>





<h4 style ="text-align:center;font-size:50px">Account Settings</h4>




<div class="main">

<div class="cards">

    <div class="image">
	<img src="personal.png" style="text-align:center">
	
	</div>
	
	<div class="title">
	<h1 >*Personal details*</h1>
	
	</div>
	

	
	<div class="des">
	   <p >Update your informations.</p>
	   </div>
	   
	   
	   <form id="Account details" action="form.php" method="post">
	<div style="text-align: center;">
	<input type="button" style="text-align:center;width:300px;height:30px" value="Manage Notifications"></Br>
	</div>
	   </form>

</div>


<!--cards -->

<br/>
<br/>
<br/>
<br/>




<div class="cards">

    <div class="image">
	<img src="payment.png"  style="text-align:center">
	
	</div>
	<br/>
	<br/>
	
	<div class="title">
	<h1 >*Payment Details*</h1>
	
	</div>
	
	<div class="des">
	   <p >Securely add or remove payment options to simplify the booking process.</p>
	   </div>
	   
	   
	   
	<div style="text-align: center;">
	<input type="button" style="text-align:center;width:300px;height:30px" value="Manage Notifications"></Br>
	</div>
	  

</div>





<!--footer
     <div class="footer">
        <div class="leftblock">
            <h1>CONTACT US</h1>
            <h3>Email:ABC123@gmail.com</h3>
            <h3>Call :+94xxxxxxxx</h3>
        </div>
        <div class="midblock1">
            <ul>
                <li><a href="">HOW IT WORKS</a></li>
                <li><a href="">SUPPORT</a></li>
                <li><a href="">FAQs</a></li>
                <li><a href="">PRIVACY POLICY</a></li>
                <li><a href="">TERMS OF SERVICE</a></li>
            </ul>
        </div>
        <div class="midblock2">
            <img src="photos/texpresscover.png" class="img">
            <h6>Copyright 2023 ALL Rights Reserved</h6>
        </div>
       <div class="midblock3">
            <h1>NEWS LETTER</h1>
            <form>
                <input type="email" placeholder="Your email addres" required>
                <br>
                <button type="submit">SUBSCRIBE NOW</button>
            </form>
        </div>
        <div class="rightblock">
            <img src="photos/android.png" class="img1">
            <img src="photos/iso.png" class="img1">
        </div>

    </div>

-->




</body>

</html>