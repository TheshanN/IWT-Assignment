<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="footer.css">
    <title>footer</title>
</head>
<body>
     <!--footer-->
     <div class="footer">
        <div class="leftblockf">
            <h1>CONTACT US</h1>
            <h3>Email:ABC123@gmail.com</h3>
            <h3>Call :+94xxxxxxxx</h3>
        </div>
        <div class="midblock1">
            <ul>
                <li><a href="">HOW IT WORKS</a></li>
                <li><a href="">SUPPORT</a></li>
                <li><a href="">FAQs</a></li>
                <li><a href="">PRIVACY POLICY</a></li>
                <li><a href="">TERMS OF SERVICE</a></li>
            </ul>
        </div>
        <div class="midblock2">
            <img src="texpresscover.png" class="img">
            <h6>Copyright 2023 ALL Rights Reserved</h6>
        </div>
        <div class="midblock3">
            <h1>NEWS LETTER</h1>
            <form>
                <input type="email" placeholder="Your email addres" required>
                <br>
                <button type="submit">SUBSCRIBE NOW</button>
            </form>
        </div>
        <div class="rightblock">
            <img src="android.png" class="img1">
            <img src="iso.png" class="img1">
        </div>

    </div>
    
</body>
</html>